import {
  auth,
  db,
  onAuthStateChanged,
  signOut,
  doc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  collection,
} from "./firebase-config.js";

const divCargando = document.getElementById("cargando");
const divContenido = document.getElementById("contenidoAdmin");
const divAccesoDenegado = document.getElementById("accesoDenegado");
const cuerpoTabla = document.getElementById("cuerpoTabla");
const divMensaje = document.getElementById("mensaje");
const correoActivo = document.getElementById("correoActivo");
const btnCerrarSesion = document.getElementById("btnCerrarSesion");

let filaEnEdicion = null;

function mostrarMensaje(texto, tipo) {
  divMensaje.textContent = texto;
  divMensaje.className = `mensaje ${tipo === "error" ? "mensaje-error" : "mensaje-exito"}`;
  divMensaje.style.display = "block";
  setTimeout(() => (divMensaje.style.display = "none"), 3500);
}

// ---------- Control de acceso: solo administradores ----------
onAuthStateChanged(auth, async (usuario) => {
  if (!usuario) {
    mostrarAccesoDenegado();
    return;
  }

  const snap = await getDoc(doc(db, "usuarios", usuario.uid));
  const rol = snap.exists() ? snap.data().rol : "usuario";

  if (rol !== "admin") {
    mostrarAccesoDenegado();
    return;
  }

  correoActivo.textContent = usuario.email;
  divCargando.style.display = "none";
  divContenido.style.display = "block";
  cargarUsuarios();
});

function mostrarAccesoDenegado() {
  divCargando.style.display = "none";
  divAccesoDenegado.style.display = "block";
}

btnCerrarSesion.addEventListener("click", async (e) => {
  e.preventDefault();
  await signOut(auth);
  window.location.href = "login.html";
});

// ---------- READ: cargar la lista de usuarios ----------
async function cargarUsuarios() {
  cuerpoTabla.innerHTML = `<tr><td colspan="8" class="tabla-vacia">Cargando usuarios...</td></tr>`;

  const snap = await getDocs(collection(db, "usuarios"));

  if (snap.empty) {
    cuerpoTabla.innerHTML = `<tr><td colspan="8" class="tabla-vacia">Aún no hay usuarios registrados.</td></tr>`;
    return;
  }

  cuerpoTabla.innerHTML = "";
  snap.forEach((docSnap) => {
    cuerpoTabla.appendChild(crearFila(docSnap.id, docSnap.data()));
  });
}

function crearFila(id, datos) {
  const tr = document.createElement("tr");
  tr.dataset.id = id;

  tr.innerHTML = `
    <td data-campo="nombre">${escapar(datos.nombre)}</td>
    <td data-campo="apellido">${escapar(datos.apellido)}</td>
    <td data-campo="tipoDocumento">${escapar(datos.tipoDocumento)}</td>
    <td data-campo="numeroIdentificacion">${escapar(datos.numeroIdentificacion)}</td>
    <td data-campo="email">${escapar(datos.email)}</td>
    <td data-campo="fechaNacimiento">${escapar(datos.fechaNacimiento)}</td>
    <td>
      ${datos.documentoUrl ? `<a class="enlace-documento" href="${datos.documentoUrl}" target="_blank" rel="noopener">Ver archivo</a>` : "—"}
    </td>
    <td class="acciones">
      <button class="btn btn-secundario btn-editar">Editar</button>
      <button class="btn btn-peligro btn-eliminar">Eliminar</button>
    </td>
  `;

  tr.querySelector(".btn-editar").addEventListener("click", () => activarEdicion(tr, id));
  tr.querySelector(".btn-eliminar").addEventListener("click", () => eliminarUsuario(id, tr));

  return tr;
}

function escapar(texto) {
  const div = document.createElement("div");
  div.textContent = texto ?? "";
  return div.innerHTML;
}

// ---------- UPDATE: editar en línea ----------
const CAMPOS_EDITABLES = ["nombre", "apellido", "numeroIdentificacion", "email", "fechaNacimiento"];

function activarEdicion(tr, id) {
  if (filaEnEdicion && filaEnEdicion !== tr) {
    cancelarEdicion(filaEnEdicion);
  }
  filaEnEdicion = tr;

  CAMPOS_EDITABLES.forEach((campo) => {
    const celda = tr.querySelector(`[data-campo="${campo}"]`);
    const valorActual = celda.textContent;
    celda.innerHTML = `<input type="text" value="${valorActual}" data-valor="${campo}" />`;
  });

  const celdaAcciones = tr.querySelector(".acciones");
  celdaAcciones.innerHTML = `
    <button class="btn btn-primario btn-guardar">Guardar</button>
    <button class="btn btn-secundario btn-cancelar">Cancelar</button>
  `;

  celdaAcciones.querySelector(".btn-guardar").addEventListener("click", () => guardarEdicion(tr, id));
  celdaAcciones.querySelector(".btn-cancelar").addEventListener("click", () => cargarUsuarios());
}

function cancelarEdicion() {
  cargarUsuarios();
  filaEnEdicion = null;
}

async function guardarEdicion(tr, id) {
  const datosActualizados = {};
  CAMPOS_EDITABLES.forEach((campo) => {
    const input = tr.querySelector(`[data-valor="${campo}"]`);
    datosActualizados[campo] = input.value.trim();
  });

  try {
    await updateDoc(doc(db, "usuarios", id), datosActualizados);
    mostrarMensaje("Usuario actualizado correctamente.", "exito");
    filaEnEdicion = null;
    cargarUsuarios();
  } catch (error) {
    console.error(error);
    mostrarMensaje("No se pudo actualizar el usuario.", "error");
  }
}

// ---------- DELETE: eliminar usuario ----------
async function eliminarUsuario(id, tr) {
  const confirmado = window.confirm("¿Seguro que deseas eliminar este registro? Esta acción no se puede deshacer.");
  if (!confirmado) return;

  try {
    await deleteDoc(doc(db, "usuarios", id));
    tr.remove();
    mostrarMensaje("Usuario eliminado.", "exito");
    if (!cuerpoTabla.children.length) {
      cuerpoTabla.innerHTML = `<tr><td colspan="8" class="tabla-vacia">Aún no hay usuarios registrados.</td></tr>`;
    }
  } catch (error) {
    console.error(error);
    mostrarMensaje("No se pudo eliminar el usuario.", "error");
  }
}
