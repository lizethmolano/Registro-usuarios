import {
  auth,
  db,
  signInWithEmailAndPassword,
  doc,
  getDoc,
} from "./firebase-config.js";

const form = document.getElementById("formLogin");
const btnLogin = document.getElementById("btnLogin");
const divMensaje = document.getElementById("mensaje");

function mostrarMensaje(texto, tipo) {
  divMensaje.textContent = texto;
  divMensaje.className = `mensaje ${tipo === "error" ? "mensaje-error" : "mensaje-exito"}`;
  divMensaje.style.display = "block";
}

function traducirError(codigo) {
  const mapa = {
    "auth/invalid-credential": "Correo o contraseña incorrectos.",
    "auth/user-not-found": "No existe una cuenta con ese correo.",
    "auth/wrong-password": "Contraseña incorrecta.",
    "auth/too-many-requests": "Demasiados intentos. Intenta más tarde.",
  };
  return mapa[codigo] || "No fue posible iniciar sesión. Intenta de nuevo.";
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  divMensaje.style.display = "none";

  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  btnLogin.disabled = true;
  btnLogin.textContent = "Ingresando...";

  try {
    const credencial = await signInWithEmailAndPassword(auth, email, password);
    const snap = await getDoc(doc(db, "usuarios", credencial.user.uid));
    const rol = snap.exists() ? snap.data().rol : "usuario";

    if (rol === "admin") {
      window.location.href = "admin.html";
    } else {
      mostrarMensaje("Inicio de sesión exitoso.", "exito");
      // Aquí puedes redirigir a una vista de perfil de usuario normal
    }
  } catch (error) {
    console.error(error);
    mostrarMensaje(traducirError(error.code), "error");
  } finally {
    btnLogin.disabled = false;
    btnLogin.textContent = "Iniciar Sesión";
  }
});
