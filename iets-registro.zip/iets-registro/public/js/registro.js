import {
  auth,
  db,
  storage,
  createUserWithEmailAndPassword,
  doc,
  setDoc,
  serverTimestamp,
  ref,
  uploadBytes,
  getDownloadURL,
} from "./firebase-config.js";

const TAMANO_MAXIMO_MB = 5;
const TIPOS_PERMITIDOS = ["application/pdf", "image/jpeg", "image/png"];

const form = document.getElementById("formRegistro");
const btnEnviar = document.getElementById("btnEnviar");
const divMensaje = document.getElementById("mensaje");

function mostrarMensaje(texto, tipo) {
  divMensaje.textContent = texto;
  divMensaje.className = `mensaje ${tipo === "error" ? "mensaje-error" : "mensaje-exito"}`;
  divMensaje.style.display = "block";
  divMensaje.scrollIntoView({ behavior: "smooth", block: "center" });
}

function limpiarErrores() {
  document.querySelectorAll(".campo-error").forEach((el) => (el.textContent = ""));
}

function marcarError(campo, texto) {
  const el = document.querySelector(`[data-error-for="${campo}"]`);
  if (el) el.textContent = texto;
}

function validarFormulario(datos, archivo) {
  let valido = true;

  if (!datos.nombre.trim()) { marcarError("nombre", "El nombre es obligatorio."); valido = false; }
  if (!datos.apellido.trim()) { marcarError("apellido", "El apellido es obligatorio."); valido = false; }
  if (!datos.tipoDocumento) { marcarError("tipoDocumento", "Selecciona un tipo de documento."); valido = false; }
  if (!datos.numeroIdentificacion.trim()) { marcarError("numeroIdentificacion", "El número de identificación es obligatorio."); valido = false; }
  if (!datos.fechaNacimiento) { marcarError("fechaNacimiento", "La fecha de nacimiento es obligatoria."); valido = false; }
  if (!datos.email.trim()) { marcarError("email", "El correo es obligatorio."); valido = false; }
  if (datos.password.length < 6) { marcarError("password", "La contraseña debe tener al menos 6 caracteres."); valido = false; }

  if (!archivo) {
    marcarError("documento", "Debes adjuntar un documento.");
    valido = false;
  } else {
    if (!TIPOS_PERMITIDOS.includes(archivo.type)) {
      marcarError("documento", "Formato no permitido. Solo PDF, JPG o PNG.");
      valido = false;
    }
    if (archivo.size > TAMANO_MAXIMO_MB * 1024 * 1024) {
      marcarError("documento", `El archivo supera el límite de ${TAMANO_MAXIMO_MB} MB.`);
      valido = false;
    }
  }

  if (!document.getElementById("terminos").checked) {
    marcarError("terminos", "Debes aceptar los términos y condiciones.");
    valido = false;
  }

  return valido;
}

function traducirError(codigo) {
  const mapa = {
    "auth/email-already-in-use": "Este correo ya está registrado.",
    "auth/weak-password": "La contraseña debe tener al menos 6 caracteres.",
    "auth/invalid-email": "El correo electrónico no es válido.",
    "auth/network-request-failed": "Error de conexión. Verifica tu internet.",
  };
  return mapa[codigo] || "Ocurrió un error al registrar. Intenta de nuevo.";
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  limpiarErrores();
  divMensaje.style.display = "none";

  const datos = {
    nombre: document.getElementById("nombre").value,
    apellido: document.getElementById("apellido").value,
    tipoDocumento: document.getElementById("tipoDocumento").value,
    numeroIdentificacion: document.getElementById("numeroIdentificacion").value,
    fechaNacimiento: document.getElementById("fechaNacimiento").value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value,
  };
  const archivo = document.getElementById("documento").files[0];

  if (!validarFormulario(datos, archivo)) return;

  btnEnviar.disabled = true;
  btnEnviar.textContent = "Enviando...";

  try {
    // 1. Crear el usuario en Firebase Authentication
    const credencial = await createUserWithEmailAndPassword(auth, datos.email, datos.password);
    const uid = credencial.user.uid;

    // 2. Subir el documento adjunto a Firebase Storage
    const rutaArchivo = `documentos/${uid}/${archivo.name}`;
    const referenciaStorage = ref(storage, rutaArchivo);
    await uploadBytes(referenciaStorage, archivo);
    const urlDocumento = await getDownloadURL(referenciaStorage);

    // 3. Guardar los datos personales en Firestore
    await setDoc(doc(db, "usuarios", uid), {
      nombre: datos.nombre,
      apellido: datos.apellido,
      tipoDocumento: datos.tipoDocumento,
      numeroIdentificacion: datos.numeroIdentificacion,
      fechaNacimiento: datos.fechaNacimiento,
      email: datos.email,
      documentoUrl: urlDocumento,
      documentoNombre: archivo.name,
      rol: "usuario",
      creadoEn: serverTimestamp(),
    });

    mostrarMensaje("Registro exitoso. Ya puedes iniciar sesión.", "exito");
    form.reset();
    setTimeout(() => (window.location.href = "login.html"), 1800);
  } catch (error) {
    console.error(error);
    mostrarMensaje(traducirError(error.code), "error");
  } finally {
    btnEnviar.disabled = false;
    btnEnviar.textContent = "Enviar Registro";
  }
});
