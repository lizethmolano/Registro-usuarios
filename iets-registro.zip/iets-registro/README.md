# Módulo de Registro de Usuarios — IETS

Formulario público de registro con carga de documentos + panel administrador (CRUD),
construido con **HTML/CSS/JavaScript** y **Firebase** (Authentication, Firestore, Storage, Hosting).

No requiere paso de compilación (no usa React/webpack): son archivos estáticos que
usan el SDK de Firebase directamente desde CDN, así que puedes abrirlos, editarlos
y desplegarlos sin instalar dependencias de Node.

## Estructura del proyecto

```
iets-registro/
├── public/
│   ├── index.html          # Formulario de registro (público)
│   ├── login.html          # Inicio de sesión
│   ├── admin.html          # Panel administrador (CRUD, solo rol admin)
│   ├── css/
│   │   └── styles.css      # Estilos institucionales (tokens de marca)
│   ├── js/
│   │   ├── firebase-config.js
│   │   ├── registro.js
│   │   ├── login.js
│   │   └── admin.js
│   └── assets/             # Aquí van los logos oficiales (PNG/SVG)
├── firebase.json
├── firestore.rules
├── storage.rules
└── README.md
```

## 1. Crear el proyecto en Firebase

1. Ve a https://console.firebase.google.com/ y crea un proyecto nuevo.
2. **Authentication** → pestaña *Sign-in method* → habilita **Correo/contraseña**.
3. **Firestore Database** → crear base de datos (modo producción; las reglas ya están incluidas).
4. **Storage** → habilitar (modo producción; las reglas ya están incluidas).
5. **Configuración del proyecto → Tus apps → Web (</>)** → registra la app y copia el objeto `firebaseConfig`.

## 2. Configurar las credenciales

Abre `public/js/firebase-config.js` y reemplaza estos valores con los de tu proyecto:

```js
const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "TU_PROYECTO.firebaseapp.com",
  projectId: "TU_PROYECTO",
  storageBucket: "TU_PROYECTO.appspot.com",
  messagingSenderId: "TU_SENDER_ID",
  appId: "TU_APP_ID",
};
```

> Estos valores no son secretos (van del lado del cliente), pero de todas formas
> la seguridad real la dan las reglas de Firestore/Storage, no la apiKey.

## 3. Crear el primer usuario administrador

Los usuarios nuevos se crean con `rol: "usuario"` por defecto. Para dar acceso
al panel admin:

1. Registra una cuenta normal desde `index.html`.
2. Ve a **Firestore Database** en la consola de Firebase → colección `usuarios`.
3. Busca el documento con el `uid` de esa cuenta y cambia el campo `rol` a `"admin"`.
4. Inicia sesión de nuevo en `login.html`: te redirigirá automáticamente a `admin.html`.

## 4. Probar en local

Como el proyecto usa módulos de JavaScript (`type="module"`), no puedes abrir
los `.html` con doble clic; necesitas servirlos con un servidor local:

```bash
npm install -g firebase-tools
firebase login
firebase init hosting     # selecciona el proyecto, public directory = "public"
firebase emulators:start  # o simplemente: firebase serve
```

Esto te da una URL local (normalmente `http://localhost:5000`).

## 5. Agregar los logos institucionales

En `public/index.html`, `login.html` y `admin.html` reemplaza:

```html
<div class="logo-placeholder">Ministerio de Salud</div>
```

por:

```html
<img src="assets/logo-minsalud.png" alt="Ministerio de Salud" style="height:40px;">
```

Y ajusta los colores/tipografías en `public/css/styles.css` (bloque `:root` al inicio
del archivo) según la guía de estilos oficial de iets.org.co.

## 6. Subir a GitHub

```bash
git init
git add .
git commit -m "Módulo de registro de usuarios - versión inicial"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/TU-REPO.git
git push -u origin main
```

## 7. Desplegar

### Opción A — Firebase Hosting (recomendada, todo en un solo lugar)

```bash
firebase deploy
```

Te entrega una URL pública tipo `https://tu-proyecto.web.app`.

### Opción B — Netlify

1. En https://netlify.com → **Add new site → Import an existing project**.
2. Conecta el repositorio de GitHub.
3. Build command: (vacío, no hay build) — Publish directory: `public`.
4. Deploy.

### Integración continua (CI/CD)

Si en `firebase init hosting` respondes "sí" a *Set up automatic builds with GitHub?*,
Firebase genera automáticamente:

```
.github/workflows/firebase-hosting-merge.yml        # deploy a producción en cada push a main
.github/workflows/firebase-hosting-pull-request.yml # preview por cada Pull Request
```

## 8. Desplegar las reglas de seguridad

No olvides publicar `firestore.rules` y `storage.rules` (no basta con tenerlas en el repo):

```bash
firebase deploy --only firestore:rules,storage:rules
```

## Pendientes antes de entregar a producción

- [ ] Reemplazar los placeholders de logos por los archivos oficiales en `public/assets/`.
- [ ] Ajustar la paleta de colores y tipografías en `styles.css` según la guía de marca real de iets.org.co.
- [ ] Redactar el texto legal de "Términos y condiciones" (actualmente el enlace no tiene contenido).
- [ ] Definir a qué vista se redirige un usuario normal (no admin) después de iniciar sesión.
- [ ] Configurar el dominio personalizado en Firebase Hosting si se requiere (ej. `registro.iets.org.co`).
